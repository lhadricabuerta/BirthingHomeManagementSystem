@include('layouts.admin.header')

    @include('layouts.admin.main-header')
    @yield('content')

@include('layouts.admin.footer')
