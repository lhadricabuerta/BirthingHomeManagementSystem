    <button class="theme-toggle" onclick="toggleDarkMode()" aria-label="Toggle dark mode">
        <i class="fas fa-moon"></i>
    </button>
