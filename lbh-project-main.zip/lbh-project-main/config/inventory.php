<?php

return [
    // Number of days before expiry when the system should start sending daily alerts
    'expiry_notice_days' => env('EXPIRY_NOTICE_DAYS', 30),
];
